﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Management;
using System.Security.Cryptography;
using System.IO;
using System.Globalization;
using System.Net.Sockets;
namespace ows_core
{
    public partial class Reseller_panel : Form
    {
        public Reseller_panel()
        {
            InitializeComponent();
        }

        private void clsButtonGreen1_Click(object sender, EventArgs e)
        {
           
            if (File.Exists(path() + "\\keys\\"))
            {
           
                File.WriteAllText(Directory.GetCurrentDirectory() + @"\keys" + ambiance_TextBox1.Text + ".txt", "summper_" + hwid_txt);
                MessageBox.Show("Key Generated!");
            } else
            {
                Directory.CreateDirectory(Directory.GetCurrentDirectory() + @"\keys");
                File.WriteAllText(path() + @"\keys" + ambiance_TextBox1.Text + ".txt", "summper_" + hwid_txt);
               
            }

            ambiance_TextBox1.Text = RandomString(4) + "-" +RandomString(4) + "-" +RandomString(4) + "-" +RandomString(4) + "-" + RandomString(4);
            write_status("Key Generated!");
        }
        private void write_status(string s)
        {
            statustxt.Text = "status: " + s;
        }
        private string path()
        {
            return System.IO.Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]);
        }

        private void clsButtonBlue1_Click(object sender, EventArgs e)
        {

        }

        private static Random random = new Random();
        public static string RandomString(int length)
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, length)
              .Select(s => s[random.Next(s.Length)]).ToArray());
        }
        private void clsButtonBlue1_Click_1(object sender, EventArgs e)
        {
            File.WriteAllText(path() + "\\keys\\" + ambiance_TextBox1.Text + ".txt", "summper_" + hwidd.Text);
            string temp;
            temp = "Key created at: " + path() + "\\keys\\" + ambiance_TextBox1.Text + ".txt";
            write_status(temp);
        }

        private void clsButtonOrange1_Click(object sender, EventArgs e)
        {
            hwidd.Text = FingerPrint.Value();
        }

        private void clsButtonPurple1_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(ambiance_TextBox1.Text);
        }

        private void clsButtonGrey1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
