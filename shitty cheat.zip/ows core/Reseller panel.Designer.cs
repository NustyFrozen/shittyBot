﻿namespace ows_core
{
    partial class Reseller_panel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.advantiumTheme1 = new AdvantiumTheme();
            this.clsButtonOrange1 = new CS_ClassLibraryTester.clsButtonOrange();
            this.statustxt = new Ambiance.Ambiance_Label();
            this.clsButtonBlue1 = new CS_ClassLibraryTester.clsButtonBlue();
            this.ambiance_Label2 = new Ambiance.Ambiance_Label();
            this.ambiance_Label1 = new Ambiance.Ambiance_Label();
            this.hwidd = new Ambiance.Ambiance_TextBox();
            this.ambiance_TextBox1 = new Ambiance.Ambiance_TextBox();
            this.hwid_txt = new CS_ClassLibraryTester.clsButtonGreen();
            this.clsButtonPurple1 = new CS_ClassLibraryTester.clsButtonPurple();
            this.clsButtonGrey1 = new CS_ClassLibraryTester.clsButtonGrey();
            this.advantiumTheme1.SuspendLayout();
            this.SuspendLayout();
            // 
            // advantiumTheme1
            // 
            this.advantiumTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.advantiumTheme1.Controls.Add(this.clsButtonGrey1);
            this.advantiumTheme1.Controls.Add(this.clsButtonPurple1);
            this.advantiumTheme1.Controls.Add(this.clsButtonOrange1);
            this.advantiumTheme1.Controls.Add(this.statustxt);
            this.advantiumTheme1.Controls.Add(this.clsButtonBlue1);
            this.advantiumTheme1.Controls.Add(this.ambiance_Label2);
            this.advantiumTheme1.Controls.Add(this.ambiance_Label1);
            this.advantiumTheme1.Controls.Add(this.hwidd);
            this.advantiumTheme1.Controls.Add(this.ambiance_TextBox1);
            this.advantiumTheme1.Controls.Add(this.hwid_txt);
            this.advantiumTheme1.Customization = "KCgo/0FBQf8AAAD/APx8/w==";
            this.advantiumTheme1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.advantiumTheme1.Font = new System.Drawing.Font("Verdana", 8F);
            this.advantiumTheme1.Image = null;
            this.advantiumTheme1.Location = new System.Drawing.Point(0, 0);
            this.advantiumTheme1.Movable = true;
            this.advantiumTheme1.Name = "advantiumTheme1";
            this.advantiumTheme1.NoRounding = false;
            this.advantiumTheme1.Sizable = true;
            this.advantiumTheme1.Size = new System.Drawing.Size(406, 231);
            this.advantiumTheme1.SmartBounds = true;
            this.advantiumTheme1.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation;
            this.advantiumTheme1.TabIndex = 0;
            this.advantiumTheme1.Text = "Admin panel";
            this.advantiumTheme1.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.advantiumTheme1.Transparent = false;
            // 
            // clsButtonOrange1
            // 
            this.clsButtonOrange1.Customization = "9fX1/6mpqf8=";
            this.clsButtonOrange1.Font = new System.Drawing.Font("Verdana", 8F);
            this.clsButtonOrange1.Image = null;
            this.clsButtonOrange1.Location = new System.Drawing.Point(126, 178);
            this.clsButtonOrange1.Name = "clsButtonOrange1";
            this.clsButtonOrange1.NoRounding = false;
            this.clsButtonOrange1.Size = new System.Drawing.Size(102, 28);
            this.clsButtonOrange1.TabIndex = 7;
            this.clsButtonOrange1.Text = "Set My HWID";
            this.clsButtonOrange1.Transparent = false;
            this.clsButtonOrange1.Click += new System.EventHandler(this.clsButtonOrange1_Click);
            // 
            // statustxt
            // 
            this.statustxt.AutoSize = true;
            this.statustxt.BackColor = System.Drawing.Color.Transparent;
            this.statustxt.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.statustxt.ForeColor = System.Drawing.Color.White;
            this.statustxt.Location = new System.Drawing.Point(12, 209);
            this.statustxt.Name = "statustxt";
            this.statustxt.Size = new System.Drawing.Size(42, 13);
            this.statustxt.TabIndex = 6;
            this.statustxt.Text = "Status:";
            // 
            // clsButtonBlue1
            // 
            this.clsButtonBlue1.Customization = "9fX1/6mpqf8=";
            this.clsButtonBlue1.Font = new System.Drawing.Font("Verdana", 8F);
            this.clsButtonBlue1.Image = null;
            this.clsButtonBlue1.Location = new System.Drawing.Point(247, 141);
            this.clsButtonBlue1.Name = "clsButtonBlue1";
            this.clsButtonBlue1.NoRounding = false;
            this.clsButtonBlue1.Size = new System.Drawing.Size(112, 31);
            this.clsButtonBlue1.TabIndex = 5;
            this.clsButtonBlue1.Text = "Create Key";
            this.clsButtonBlue1.Transparent = false;
            this.clsButtonBlue1.Click += new System.EventHandler(this.clsButtonBlue1_Click_1);
            // 
            // ambiance_Label2
            // 
            this.ambiance_Label2.AutoSize = true;
            this.ambiance_Label2.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Label2.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.ambiance_Label2.ForeColor = System.Drawing.Color.White;
            this.ambiance_Label2.Location = new System.Drawing.Point(18, 115);
            this.ambiance_Label2.Name = "ambiance_Label2";
            this.ambiance_Label2.Size = new System.Drawing.Size(52, 20);
            this.ambiance_Label2.TabIndex = 4;
            this.ambiance_Label2.Text = "HWID:";
            // 
            // ambiance_Label1
            // 
            this.ambiance_Label1.AutoSize = true;
            this.ambiance_Label1.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_Label1.Font = new System.Drawing.Font("Segoe UI", 11F);
            this.ambiance_Label1.ForeColor = System.Drawing.Color.White;
            this.ambiance_Label1.Location = new System.Drawing.Point(34, 72);
            this.ambiance_Label1.Name = "ambiance_Label1";
            this.ambiance_Label1.Size = new System.Drawing.Size(36, 20);
            this.ambiance_Label1.TabIndex = 3;
            this.ambiance_Label1.Text = "Key:";
            // 
            // hwidd
            // 
            this.hwidd.BackColor = System.Drawing.Color.Transparent;
            this.hwidd.Font = new System.Drawing.Font("Tahoma", 11F);
            this.hwidd.ForeColor = System.Drawing.Color.DimGray;
            this.hwidd.Location = new System.Drawing.Point(76, 107);
            this.hwidd.MaxLength = 32767;
            this.hwidd.Multiline = false;
            this.hwidd.Name = "hwidd";
            this.hwidd.ReadOnly = false;
            this.hwidd.Size = new System.Drawing.Size(297, 28);
            this.hwidd.TabIndex = 2;
            this.hwidd.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.hwidd.UseSystemPasswordChar = false;
            // 
            // ambiance_TextBox1
            // 
            this.ambiance_TextBox1.BackColor = System.Drawing.Color.Transparent;
            this.ambiance_TextBox1.Font = new System.Drawing.Font("Tahoma", 11F);
            this.ambiance_TextBox1.ForeColor = System.Drawing.Color.DimGray;
            this.ambiance_TextBox1.Location = new System.Drawing.Point(76, 64);
            this.ambiance_TextBox1.MaxLength = 32767;
            this.ambiance_TextBox1.Multiline = false;
            this.ambiance_TextBox1.Name = "ambiance_TextBox1";
            this.ambiance_TextBox1.ReadOnly = false;
            this.ambiance_TextBox1.Size = new System.Drawing.Size(297, 28);
            this.ambiance_TextBox1.TabIndex = 1;
            this.ambiance_TextBox1.TextAlignment = System.Windows.Forms.HorizontalAlignment.Left;
            this.ambiance_TextBox1.UseSystemPasswordChar = false;
            // 
            // hwid_txt
            // 
            this.hwid_txt.Customization = "9fX1/6mpqf8=";
            this.hwid_txt.Font = new System.Drawing.Font("Verdana", 8F);
            this.hwid_txt.Image = null;
            this.hwid_txt.Location = new System.Drawing.Point(126, 141);
            this.hwid_txt.Name = "hwid_txt";
            this.hwid_txt.NoRounding = false;
            this.hwid_txt.Size = new System.Drawing.Size(102, 31);
            this.hwid_txt.TabIndex = 0;
            this.hwid_txt.Text = "Generate Key";
            this.hwid_txt.Transparent = false;
            this.hwid_txt.Click += new System.EventHandler(this.clsButtonGreen1_Click);
            // 
            // clsButtonPurple1
            // 
            this.clsButtonPurple1.Customization = "9fX1/6mpqf8=";
            this.clsButtonPurple1.Font = new System.Drawing.Font("Verdana", 8F);
            this.clsButtonPurple1.Image = null;
            this.clsButtonPurple1.Location = new System.Drawing.Point(247, 178);
            this.clsButtonPurple1.Name = "clsButtonPurple1";
            this.clsButtonPurple1.NoRounding = false;
            this.clsButtonPurple1.Size = new System.Drawing.Size(112, 28);
            this.clsButtonPurple1.TabIndex = 8;
            this.clsButtonPurple1.Text = "Copy Key";
            this.clsButtonPurple1.Transparent = false;
            this.clsButtonPurple1.Click += new System.EventHandler(this.clsButtonPurple1_Click);
            // 
            // clsButtonGrey1
            // 
            this.clsButtonGrey1.Customization = "9fX1/6mpqf8=";
            this.clsButtonGrey1.Font = new System.Drawing.Font("Verdana", 8F);
            this.clsButtonGrey1.Image = null;
            this.clsButtonGrey1.Location = new System.Drawing.Point(363, 0);
            this.clsButtonGrey1.Name = "clsButtonGrey1";
            this.clsButtonGrey1.NoRounding = false;
            this.clsButtonGrey1.Size = new System.Drawing.Size(43, 23);
            this.clsButtonGrey1.TabIndex = 9;
            this.clsButtonGrey1.Text = "X";
            this.clsButtonGrey1.Transparent = false;
            this.clsButtonGrey1.Click += new System.EventHandler(this.clsButtonGrey1_Click);
            // 
            // Reseller_panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 231);
            this.Controls.Add(this.advantiumTheme1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Reseller_panel";
            this.Text = "Admin Panel";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.advantiumTheme1.ResumeLayout(false);
            this.advantiumTheme1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private AdvantiumTheme advantiumTheme1;
        private Ambiance.Ambiance_TextBox ambiance_TextBox1;
        private CS_ClassLibraryTester.clsButtonGreen hwid_txt;
        private System.Windows.Forms.Timer timer1;
        private Ambiance.Ambiance_Label ambiance_Label2;
        private Ambiance.Ambiance_Label ambiance_Label1;
        private Ambiance.Ambiance_TextBox hwidd;
        private CS_ClassLibraryTester.clsButtonBlue clsButtonBlue1;
        private Ambiance.Ambiance_Label statustxt;
        private CS_ClassLibraryTester.clsButtonOrange clsButtonOrange1;
        private CS_ClassLibraryTester.clsButtonPurple clsButtonPurple1;
        private CS_ClassLibraryTester.clsButtonGrey clsButtonGrey1;
    }
}